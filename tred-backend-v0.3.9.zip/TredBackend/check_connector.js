"use strict";
// Protocol fixtures only; this does not certify the live broker's current schema.
const assert=require("node:assert/strict"),fs=require("node:fs"),vm=require("node:vm");
let sockets=[],sent=[],forwarded=[];
class Socket {
  constructor(url){this.url=url;this.handlers={};sockets.push(this);}
  addEventListener(name,fn){this.handlers[name]=fn;}
  send(value){sent.push(value);}
  emit(data){this.handlers.message?.({data});}
}
const sandbox={window:{WebSocket:Socket,postMessage:(value)=>forwarded.push(value)},location:{origin:"https://pocketoption.com"},URL,Blob,ArrayBuffer,TextDecoder,Date,Promise,Number,JSON,Object,crypto:require('node:crypto'),console};
vm.runInNewContext(fs.readFileSync("connector/observer.js","utf8"),sandbox);
const socket=new sandbox.window.WebSocket("wss://demo-api-eu.po.market/socket.io/?EIO=4&transport=websocket");
socket.emit('42["auth",{"session":"fixture-secret-never-forward","uid":456,"isDemo":1}]');
socket.emit('42["successauth",{"session":"fixture-secret-never-forward","uid":456,"isDemo":1,"currency":"USD","balance":100}]');
socket.emit('42["successupdateBalance",{"balance":108,"isDemo":1}]');
socket.emit('451-["updateStream",{"_placeholder":true,"num":0}]');
socket.emit(new TextEncoder().encode(JSON.stringify([["EURUSD",Date.now()/1000,1.1]])).buffer);
socket.emit('42'+JSON.stringify(["updateStream",[["EURUSD",Date.now()/1000+7200,1.2]]]));
socket.emit('42'+JSON.stringify(["loadHistoryPeriod",{asset:"EURUSD",period:60,data:[{time:Math.floor(Date.now()/60000)*60+7200,open:1.1,close:1.2,high:1.3,low:1.0}]}]));
socket.emit('42["successcloseOrder",{"session":"fixture-secret-never-forward","uid":456}]'); // Incomplete result must be ignored.
setImmediate(async()=>{
  const events=forwarded.flatMap(x=>x.events);
  assert.equal(sent.length,0,"Observer must never send an order or subscription");
  assert.equal(events.filter(x=>x.type==="account").length,2);
  assert.equal(events.find(x=>x.type==="account").mode,"demo");
  assert.equal(events.filter(x=>x.type==="quote").length,2);
  const market=events.filter(x=>["quote","candle"].includes(x.type));
  assert(market.every(x=>x.source_clock==="po-market-native-v1"));
  assert(events.some(x=>x.type==="quote"&&x.time>Date.now()/1000+7190),"Observer preserves source clock; no arrival-time substitution");
  assert.equal(events.filter(x=>x.type==="candle").length,1,"Closed-bar filter must wait for worker clock decoding");
  assert.equal(events.filter(x=>x.type==="trade").length,0);
  assert(!JSON.stringify(forwarded).includes("fixture-secret"));
  assert(events.every(x=>!Object.hasOwn(x,"session") && !Object.hasOwn(x,"password")));
  forwarded=[];
  const other=new sandbox.window.WebSocket("wss://api-eu.po.market/socket.io/?EIO=4&transport=websocket");
  other.emit('42["successupdateBalance",{"balance":2,"isDemo":1}]');
  other.emit('42["successauth",{"uid":789,"isDemo":1,"session":"fixture-secret-never-forward"}]');
  other.emit('451-["successupdateBalance",{"_placeholder":true,"num":0}]');
  other.emit(new Blob(['{"balance":"12.34","isDemo":1}']));
  other.emit('{"uid":789,"balance":12.35,"isDemo":1,"currency":"USD"}');
  other.emit('{"uid":999,"balance":44,"isDemo":1}');
  other.emit('42["successupdateBalance",{"uid":999,"balance":45,"isDemo":0}]');
  other.emit('42["successauth",{"uid":123,"currency":"USD","isDemo":1}]');
  other.emit('42["successupdateBalance",{"balance":20}]');
  socket.emit('42["successupdateBalance",{"balance":110,"isDemo":1}]');
  await new Promise(setImmediate);
  const accounts=forwarded.flatMap(x=>x.events).filter(x=>x.type==="account");
  const at=balance=>accounts.find(x=>x.balance===balance);
  assert.equal(accounts.length,7);
  assert.equal(at('2').account_id,null,"No identity from a different socket");
  assert.equal(at('12.34').account_id,"789");assert.equal(at('12.34').currency,null,"USD is not inferred");
  assert.equal(at('12.35').currency,"USD","Explicit unframed broker balance is supported");
  assert.equal(at('44').account_id,"999");assert.equal(at('44').currency,null,"Currency is reset on account change");
  assert.equal(at('45').mode,"real");assert.equal(at('45').currency,null,"Currency is not inherited across modes");
  assert.equal(at('20').mode,null,"Mode must be explicit on a balance event");
  assert.equal(at('110').account_id,"456");assert.equal(at('110').currency,"USD");
  assert(!JSON.stringify(forwarded).includes("fixture-secret"));assert.equal(sent.length,0);
  forwarded=[];
  const aliases=new sandbox.window.WebSocket("wss://api-eu.po.market/socket.io/");
  aliases.emit('42["successauth",{"id":321,"isDemo":1}]');
  aliases.emit('42["successupdateBalance",{"balance":31,"isDemo":1,"currency":"USD"}]');
  aliases.emit('42["successauth",{"accountId":"654","isDemo":0,"balance":32,"currency":"USD"}]');
  aliases.emit('42["successauth",{"uid":345,"id":346,"isDemo":1,"balance":33}]');
  aliases.emit('42["successupdateBalance",{"uid":"bad","balance":34,"isDemo":1}]');
  const generic=new sandbox.window.WebSocket("wss://api-eu.po.market/socket.io/");
  generic.emit('42["successupdateBalance",{"id":987,"balance":35,"isDemo":1}]');
  generic.emit('42["successupdateBalance",{"accountId":"777","balance":36,"isDemo":0}]');
  await new Promise(setImmediate);
  const selected=forwarded.flatMap(x=>x.events).filter(x=>x.type==="account");
  const balance=value=>selected.find(x=>x.balance===value);
  assert.equal(balance('31').account_id,'321');assert.equal(balance('32').account_id,'654');
  assert.notEqual(balance('31').source_stream,balance('32').source_stream,"Reauthentication rotates the manual confirmation boundary");
  assert.equal(balance('33').account_id,null);assert.equal(balance('33').id_status,'conflict');
  assert.equal(balance('34').account_id,null);assert.equal(balance('34').id_status,'invalid');
  assert.equal(balance('35').account_id,null,"Generic balance id is not an account ID");
  assert.equal(balance('36').account_id,'777');
  assert.equal(sent.length,0);
  console.log(JSON.stringify({ok:true,fixture_protocol:true,auth_fields_not_exported:true,no_outbound_commands:true,binary_quotes_decoded:true,incomplete_settlements_ignored:true,source_clock_tagged_without_timestamp_changes:true,account_identity_scoped_to_socket:true,split_metadata_and_unframed_balance:true,missing_currency_and_mode_not_guessed:true,auth_id_aliases_and_conflicts_checked:true,reauth_rotates_confirmation_context:true}));
});
