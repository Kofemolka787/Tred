"""Connection-scoped catalog validity and complete bars from observed ticks.

No timers refresh market timestamps. A catalog remains scoped to the SAME live
socket; a new socket must deliver its own catalog before it can qualify pairs.
"""
import re

FEED_ID = re.compile(r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")
SCHEMA = """
CREATE TABLE IF NOT EXISTS live_bars(user_id INTEGER NOT NULL,symbol TEXT NOT NULL,time INTEGER NOT NULL,open REAL NOT NULL,high REAL NOT NULL,low REAL NOT NULL,close REAL NOT NULL,first REAL NOT NULL,last REAL NOT NULL,gap REAL NOT NULL,count INTEGER NOT NULL,PRIMARY KEY(user_id,symbol));
CREATE INDEX IF NOT EXISTS candles_feed_lookup ON candles(user_id,symbol,period,feed_id,time DESC);
"""


def migrate(db):
    columns = {r[1] for r in db.execute("PRAGMA table_info(assets)")}
    for name, kind in (("catalog_feed", "TEXT"), ("quote_feed", "TEXT"), ("feed_connected", "INTEGER NOT NULL DEFAULT 0"), ("history_status", "TEXT"), ("history_scoped", "INTEGER NOT NULL DEFAULT 0")):
        if name not in columns:
            db.execute(f"ALTER TABLE assets ADD COLUMN {name} {kind}")
    if "origin" not in {r[1] for r in db.execute("PRAGMA table_info(candles)")}:
        db.execute("ALTER TABLE candles ADD COLUMN origin TEXT NOT NULL DEFAULT 'broker'")
    if "feed_id" not in {r[1] for r in db.execute("PRAGMA table_info(candles)")}:
        db.execute("ALTER TABLE candles ADD COLUMN feed_id TEXT")
    db.executescript(SCHEMA)


def catalog_observed(asset, now):
    """Catalog continuity alone is enough to research its scoped closed bars."""
    return bool(asset.get('feed_connected')) if asset.get('catalog_feed') else now-asset['updated_at']<=60


def catalog_current(asset, now):
    if asset.get("catalog_feed"):
        return bool(asset.get("feed_connected") and asset.get("quote_feed") == asset["catalog_feed"] and asset.get("quote_time") is not None and now-asset["quote_time"] <= 10)
    return now-asset["updated_at"] <= 60  # Old modules get no invented continuity.


def gate(asset, *, expiry, min_payout, now):
    live = asset.get("quote_time") is not None and now-asset["quote_time"] <= 10
    if not asset["is_open"]:
        code, reason = "closed", "Брокер отметил пару закрытой."
    elif asset["payout"] < min_payout:
        code, reason = "payout", f"Выплата {round(asset['payout']*100)}% ниже минимума {round(min_payout*100)}%."
    elif expiry not in asset["expiries"]:
        code, reason = "expiry", f"Брокер не подтвердил сделку на {expiry} мин."
    elif asset.get("catalog_feed") and asset.get("feed_connected") and asset.get("quote_feed") in (None, asset["catalog_feed"]) and not live:
        code, reason = "quote", "История и каталог могут поступать отдельно от цен. Ждём свежую котировку этого канала."
    elif not catalog_current(asset, now):
        code = "catalog"
        if asset.get("catalog_feed") and not asset.get("feed_connected"):
            reason = "Канал, передавший каталог, закрылся. Ждём каталог и свежую цену нового соединения Pocket Option."
        elif asset.get("catalog_feed"):
            reason = "Каталог и цена поступили из разных соединений Pocket Option. Ждём свежую цену из канала этого каталога."
        else:
            reason = "Каталог старого модуля устарел. Обнови расширение и вкладку Pocket Option."
    elif not live:
        code, reason = "quote", "Нет свежей цены: последняя котировка старше 10 секунд."
    else:
        code, reason = "ready", "Каталог и цена получены."
    # Eligible reflects metadata only; current-socket validity needs its ticks.
    eligible = bool(asset["is_open"] and asset["payout"] >= min_payout and expiry in asset["expiries"] and catalog_current(asset, now))
    return {"code": code, "reason": reason, "eligible": eligible, "quote_live": live,
            "metadata_eligible": bool(asset["is_open"] and asset["payout"] >= min_payout and expiry in asset["expiries"]),
            "catalog_age": max(0, round(now-asset["updated_at"])),
            "catalog_source": "live_socket" if asset.get("catalog_feed") else "legacy_snapshot"}


def live_tick(db, uid, pair, at, price, feed_id=None):
    """Build M1 ONLY with actual ticks near BOTH ends and no gap over 10s."""
    start = int(at//60)*60
    old = db.execute("SELECT * FROM live_bars WHERE user_id=? AND symbol=?", (uid, pair)).fetchone()
    if old and at <= old["last"]:
        return
    if old and start == old["time"]:
        db.execute("UPDATE live_bars SET high=max(high,?),low=min(low,?),close=?,last=?,gap=max(gap,?),count=count+1 WHERE user_id=? AND symbol=?", (price,price,price,at,at-old["last"],uid,pair))
        return
    if old and start == old["time"]+60 and old["count"] >= 2 and old["first"] <= old["time"]+5 and old["last"] >= old["time"]+50 and old["gap"] <= 10 and at-old["last"] <= 10:
        db.execute("INSERT INTO candles(user_id,symbol,period,time,open,high,low,close,origin,feed_id) VALUES (?,?,60,?,?,?,?,?,'ticks',?) ON CONFLICT(user_id,symbol,period,time) DO UPDATE SET open=excluded.open,high=excluded.high,low=excluded.low,close=excluded.close,origin=excluded.origin,feed_id=excluded.feed_id WHERE candles.feed_id IS NOT excluded.feed_id AND (candles.feed_id IS NOT NULL OR candles.origin='ticks')", (uid,pair,old["time"],old["open"],old["high"],old["low"],old["close"],feed_id))
    db.execute("INSERT INTO live_bars VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,symbol) DO UPDATE SET time=excluded.time,open=excluded.open,high=excluded.high,low=excluded.low,close=excluded.close,first=excluded.first,last=excluded.last,gap=excluded.gap,count=excluded.count", (uid,pair,start,price,price,price,price,at,at,0,1))
    db.execute("DELETE FROM candles WHERE user_id=? AND symbol=? AND period=60 AND time<?", (uid,pair,at-1600*60))
